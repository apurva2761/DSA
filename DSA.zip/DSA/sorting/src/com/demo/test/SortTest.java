package com.demo.test;

import java.util.Scanner;

import com.demo.service.SortService;

public class SortTest {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter array size");
		int n = sc.nextInt();
		int choice=0;
		int [] arr= new int [n];
		SortService.acceptdata(arr);
		SortService.displayData(arr);
		do {
		System.out.println("\n1.Bubble sort\n 2.selection sort\n 3.Quick sort\n 4.Merge sort\n 5.Insertion sort \n 6.Heap sort \n 7.Count sort \n8.exit choice:");
		choice=sc.nextInt();
		switch(choice)
		{
			case 1:	
				break;
			case 2:
				SortService.selectionSort(arr);
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			case 6:
				break;
			case 7:
				break;
			case 8:
				System.out.println("Thank you for visiting us!!!");
				sc.close();
			default:
				System.out.println("Invalid case");
				break;

		}
	}while(choice!=8);
}}
