package com.demo.service;

import java.util.Scanner;

public class SortService {
	public static void acceptdata(int[] arr) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter array elements");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
	}

	public static void displayData(int[] arr) {
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+"\t");
		}		
	}

	public static void selectionSort(int[] arr) {
	for(int i=0;i<arr.length-1;i++)
	{
		int min=i;
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[min]>arr[j])
				min=j;
				
		}
		int temp=arr[i];
		arr[i]=arr[min];
		arr[min]=temp;
	}
		displayData(arr);
	}

}
