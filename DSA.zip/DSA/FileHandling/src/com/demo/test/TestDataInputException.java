package com.demo.test;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.DataOutputStream;
import java.io.DataInputStream;

public class TestDataInputException {

	public static void main(String[] args) {
		try(DataInputStream dis= new DataInputStream(new FileInputStream("text.txt"));
				 DataOutputStream dos= new DataOutputStream(new FileOutputStream("textcopy2.txt"));){
			String s=dis.readLine();
			while(s!= null) {
				System.out.println(s);
				dos.writeBytes(s+"\n");
				///dos.writeUTF(s);
				s=dis.readLine();
			}
			System.out.println("Done");
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
