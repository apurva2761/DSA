package com.demo.test;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileNotFoundException;

public class TestAppend {

	public static void main(String[] args) {
		File f= new File("textcopy.txt");
		FileOutputStream  fos=null;
		if(f.exists())
		{
			try {
				fos= new FileOutputStream("textcopy.txt",true);
		}catch(FileNotFoundException e)
			{
			e.printStackTrace();
			}

	}else{
		try {
			fos=new FileOutputStream("textcopy.txt");
		}
		catch(FileNotFoundException e){
		e.printStackTrace();
		}
	}
//// Autoclosable tryblock
		try( FileInputStream fis= new FileInputStream("text.txt");
				FileOutputStream fos1=fos;)
		{
		int i=fis.read();
		while(i!= -1)
		{
			fos.write(i);
			//i=fis.read();
		}
		System.out.println("file Append done");
		}catch(FileNotFoundException e)
		{
		e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
}
}