package com.demo.test;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestBufferedInputStream {

	public static void main(String[] args) {
		File f= new File("textcopy.txt");
		BufferedOutputStream bos= null;
		if(f.exists()){
		try {
			
			bos= new BufferedOutputStream(new FileOutputStream("textcopy.txt",true));
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		}else {
			try {
				bos=new BufferedOutputStream(new FileOutputStream("textcopy.txt"));
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		

	}
		/// to read from file
		try(BufferedInputStream bis= new BufferedInputStream(new FileInputStream("text.txt"));
				BufferedOutputStream bos1=bos;){
			int i = bis.read();
			while(i!= -1)
			{
				bos.write(i);
				i=bis.read();
			}
			System.out.println("Done");
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
}
}
