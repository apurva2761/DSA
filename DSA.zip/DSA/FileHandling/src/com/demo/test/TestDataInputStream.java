package com.demo.test;

import java.io.DataInputStream;
import java.io.DataOutputStream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class TestDataInputStream {

	public static void main(String[] args) {
	try(Scanner sc= new Scanner(System.in);
			DataInputStream dis= new DataInputStream(new FileInputStream("empdata.txt"));
			DataOutputStream dos= new DataOutputStream(new FileOutputStream("empdata.txt"));){
			System.out.println("Enter id:");
			int id= sc.nextInt();
			dos.write(id);
			System.out.println("Enter Name:");
			String nm= sc.next();
			dos.writeUTF(nm);
			System.out.println("Enter dep:");
			String dep= sc.next();
			dos.writeUTF(dep);
			 
			int i=dis.readInt();
			String name= dis.readUTF();
			String dept=dis.readUTF();
			System.out.println("Id"+i+"name"+name+"department"+dept);
			
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
}
