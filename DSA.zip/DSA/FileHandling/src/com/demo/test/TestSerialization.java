package com.demo.test;
import java.util.List;

import com.demo.beans.Product;
import com.demo.service.*;
public class TestSerialization {

	public static void main(String[] args) {
	 ProductService pservice= new ProductServiceImpl();
	 pservice.writeTofile();
	 List<Product>plst=pservice.readFromFile();
	 plst.forEach(System.out::println);
	}

}
