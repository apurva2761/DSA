package com.demo.service;

import java.util.Scanner;

public class assignment2Service {
	public static void acceptData(int[] arr) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter array elements");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
	
	}

	public static void displayData(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
//sequential search
	public static void sequentialSearch(int[] arr, int num) {
		int cnt=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==num)
			{
				System.out.println("Element" +num+" found at position "+i);
				cnt++;
			}			
		}
		if(cnt>0)
		{
			System.out.println("Occurence of number "+num+" in array is:"+cnt);
		}else
		{
			System.out.println("Number not found.");
		}
	}
}
