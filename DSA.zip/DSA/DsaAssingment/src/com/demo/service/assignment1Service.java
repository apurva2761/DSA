package com.demo.service;
import java.util.Scanner;


public class assignment1Service {

	public static void acceptdata(int[] arr) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student heights :");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
	}

	public static void displayData(int[] arr) {
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+"\t");
		}		
	}

	public static int[] bubbleSort(int[] arr) {
		int cnt=0;
		for(int i=0;i<arr.length-1;i++)
		{
			for(int j=0;j<arr.length-i-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					cnt++;
				}
			}
		}
		System.out.println("Iteration in bubble sort are: "+cnt);
		return arr;
	}

	public static int[] selectionSort(int[] arr) {
		int j,cnt=0;
		for(int i=0;i<arr.length-1;i++)
		{
			int min=i;
			for(j=i+1;j<arr.length;j++)
			{
				if(arr[min]>arr[j])
				{
					min=j;
				}
			}
			int temp=arr[min];
			arr[min]=arr[i];
			arr[i]=temp;
			cnt++;

		}
		System.out.println("Iteration in selection sort are: "+cnt);

		return arr;
	}
	public static int[] insertionSort(int[] arr) {
		int cnt=0;
		for(int i=1;i<arr.length;i++)
		{
			int key=arr[i];
			int j=i-1;
			while(j>=0&&arr[j]>key)
			{
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=key;
			cnt++;

		}
		System.out.println("Iteration in insertion sort are: "+cnt);
		return arr;
	}

	public static void heapSort(int[] arr) {
		int cnt=0;
		int n=arr.length;
		for(int i=n/2-1;i>=0;i--)
		{
			heapify(arr,n,i);
		}
		
		for(int i=n-1;i>=0;i--)
		{
			int temp=arr[0];
			arr[0]=arr[i];
			arr[i]=temp;
			cnt++;
			heapify(arr,i,0);
			
		}
		System.out.println("Iteration in heap sort are: "+cnt);

	}

	private static void heapify(int[] arr, int n, int i) {
		int largest=i;
		int left=2*i+1;
		int right=2*i+2;
		if(left<n && arr[left]>arr[largest])
		{
			largest=left;
		}
		if(right<n && arr[right]>arr[largest])
		{
			largest=right;
		}
		if(largest!=i)
		{
			int temp=arr[i];
			arr[i]=arr[largest];
			arr[largest]=temp;
			
			heapify(arr,i,largest);
		}
	}
}








