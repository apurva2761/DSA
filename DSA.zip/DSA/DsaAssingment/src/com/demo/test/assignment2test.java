package com.demo.test;

import java.util.Scanner;

import com.demo.service.assignment2Service;

public class assignment2test {

	public static void main(String[] args) {
		assignment2Service service=new assignment2Service();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array:");
		int size=sc.nextInt();
		int arr[]=new int[size];
		service.acceptData(arr);
		service.displayData(arr);
		
		System.out.println("Enter number to be search:");
		int num=sc.nextInt();
		service.sequentialSearch(arr,num);
	}

}
