package com.demo.test;
import java.util.Scanner;
import com.demo.service.*;
public class assignment1test 
{

	public static void main(String[] args) 
		{
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter No Of Students:");
			int n = sc.nextInt();
			int choice=0;
			int [] arr= new int [n];
			assignment1Service.acceptdata(arr);
			assignment1Service.displayData(arr);
			do
			{
				System.out.println("\n1.Bubble sort\n 2.selection sort\n 3.Insertion sort \n 4.Heap sort \n8.exit choice:");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1: 
					int[] arr1=assignment1Service.bubbleSort(arr);
					assignment1Service.displayData(arr1);	
					break;

				case 2: 
					 arr1=assignment1Service.selectionSort(arr);
					 assignment1Service.displayData(arr1);	

					break;
				case 3:
					 arr1=assignment1Service.insertionSort(arr);
					 assignment1Service.displayData(arr1);	

					break;

				case 4:
					assignment1Service.heapSort(arr);
					assignment1Service.displayData(arr);	

					break;
				case 5:
					sc.close();
					System.out.println("Thank you !!!1");
					break;
					
					default:
						System.out.println("Invalid choice!!!!");
						break;
				}
				
				}while(choice!=8);
				
		}

}


