package com.demo.test;

import com.demo.hashtable.Hashing;

public class TestHashing {

	public static void main(String[] args) {
		Hashing h= new Hashing(5);
		h.insertData(52);
		h.insertData(40);
		h.insertData(34);
		h.insertData(12);
		h.insertData(50);
		h.displayData();
        h.searchData(34);
       // h.searchData(44);
	}

}
