package com.demo.hashtable;

//import org.w3c.dom.Node;

public class Hashing {
	Node[] heads;
	public Hashing(int size)
	{
		heads=new Node[size];
		for(int i=0;i<heads.length;i++)
		{
			heads[i]=null;
		}
	}
	
		class Node
		{
			int data;
			Node next;
	 public Node(int val)
			{
				data=val;
				next = null;
			}
	}

	public void insertData(int val) {
		Node newNode=new  Node(val);
		int pos=val%heads.length;
		if(heads==null)
		{
			heads[pos]=newNode;
		}else
		{
			newNode.next=heads[pos];
			heads[pos]=newNode;
		}
	}

	
	public void displayData() {
		Node temp;
		for(int i=0;i<heads.length;i++)
		{
			System.out.print(i+"------------>");

			for(temp=heads[i];temp!=null;temp=temp.next)
			{
				System.out.print(temp.data+" \n");

			}
		}
		System.out.println("\n------------------------------\n");
	}


	public void searchData(int i) {
		int pos=i%heads.length;
		Node temp;
		if(heads[pos]==null)
		{
			System.out.println("bucket is empty,no data found");
		}else
		{
		for(temp=heads[pos];temp!=null;temp=temp.next)
		{
			if(temp.data==i)
			{
				System.out.println("data found");
			}
		}	
		System.out.println("data not found");

		}
	}

}
