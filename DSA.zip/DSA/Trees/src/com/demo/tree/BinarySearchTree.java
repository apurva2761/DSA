package com.demo.tree;

public class BinarySearchTree {
	Node root;
	public BinarySearchTree()
	{
		root=null;
	}
	class Node{
		int data;
		Node left;
		Node right;
		public Node(int val)
		{
			data=val;
			left=null;
			right=null;
		}
	}

	public void insertKey(int val) {
		root=insertData(root,val);
		
	}

	private Node insertData(Node root, int val) {
		Node newNode=new Node(val);
		if(root==null)
		{
			root=newNode;
			return root;
		}else
		{
			if(val<root.data)
			{
				root.left=insertData(root.left,val);
			}
			else
			{
				root.right=insertData(root.right,val);
			}
			return root;

		}
	}
	
	public void inorderTraversal()
	{
		inorder(root);
	}
	
	private void inorder(Node root)
	{
		if(root!= null)
		{
			inorder(root.left);
			System.out.println(root.data);
			inorder(root.right);
		}
	}
	public void preorderTraversal()
	{
		preorder(root);
	}
	
	private void preorder(Node root)
	{
		if(root!= null)
		{
			System.out.println(root.data);
			preorder(root.left);
			preorder(root.right);
		}
	}
	public void postorderTraversal()
	{
		postorder(root);
	}
	
	private void postorder(Node root)
	{
		if(root!= null)
		{
			postorder(root.left);
			postorder(root.right);
			System.out.println(root.data);

		}
	}
	

	
}
