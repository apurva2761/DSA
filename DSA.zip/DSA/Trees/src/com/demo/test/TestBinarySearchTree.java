package com.demo.test;
import com.demo.tree.*;

public class TestBinarySearchTree {

	public static void main(String[] args) {
		BinarySearchTree blist=new BinarySearchTree();
		blist.insertKey(10);
		blist.insertKey(20);
		blist.insertKey(30);
		blist.insertKey(1);
		blist.inorderTraversal();
		System.out.println("\n------------------------------------\n");
		blist.preorderTraversal();
		System.out.println("\n------------------------------------\n");
		blist.postorderTraversal();		
		System.out.println("\n------------------------------------\n");

	}

}
