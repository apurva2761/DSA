package com.demo.test;
import java.util.Scanner;

import com.demo.service.ArrayService;

public class TestArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array: ");
		int n=sc.nextInt();
		int [] arr= new int [n];
		ArrayService.acceptData(arr);
		ArrayService.displayData(arr);
		int num=ArrayService.maxElement(arr);
		System.out.println("Max element :" +num);
		int num1=ArrayService.evenMaxElement(arr);
		if(num1!=0)
		{
			System.out.println(" Array even Max element :" +num1);
		}
		else
		{
			System.out.println("even number not found.");
		}
		int num2=ArrayService.findSumOfAllDigits(arr);
		System.out.println(" Array sum of digits of element :" +num2);

		ArrayService.findDuplicates(arr);
		int num3=4;
		ArrayService.rotateArray(num3,arr);
	}

}
