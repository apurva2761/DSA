package com.demo.test;
import java.util.Scanner;

import com.demo.service.Array2DService;
import com.demo.service.ArrayService;

public class Test2DArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array: ");
		int n=sc.nextInt();
		int [][] arr= new int [n][n];
		Array2DService.acceptData(arr);
		Array2DService.displayData(arr);
		int num=Array2DService.maxElement(arr);
		System.out.println("Max element :" +num);
		int num1=Array2DService.evenMaxElement(arr);
		if(num1!=0)
		{
			System.out.println(" Array even Max element :" +num1);
		}
		else
		{
			System.out.println("even number not found.");
		}
		int num2=Array2DService.findSumOfAllDigits(arr);
		System.out.println(" Array sum of digits of element :" +num2);

		Array2DService.findDuplicates(arr);
		int num3=4;
		Array2DService.rotateArray(num3,arr);
	}

}
