package com.demo.service;

import java.util.Scanner;

public class Array2DService {

	public static void acceptData(int[][] arr) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array Element:");
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr.length;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		
	}

	public static void displayData(int[][] arr) {
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr.length;j++)
			{
				System.out.print(arr[i][j]+" ");
			}
			System.out.println("");
		}
		
	}

	public static int maxElement(int[][] arr) {
		int max=arr[0][0];
		for(int i=1;i<arr.length;i++)
		{
			for(int j=1;j<arr.length;j++)
			{
				if(arr[i][j]>max)
					max=arr[i][j];
			}
		}
		return max;
	}

	public static int evenMaxElement(int[][] arr) {
		int max=0;
		for(int i=1;i<arr.length;i++)
		{
			for(int j=1;j<arr.length;j++)
			{
				if(arr[i][j]%2==0)
				{
					if(arr[i][j]>max)
					{
						max=arr[i][j];
					}
				}
			}

		}
		return max;
	}

	public static int findSumOfAllDigits(int[][] arr) {
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr.length;j++)
			{
				int s=findSumOfDigits(arr[i][j]);
				System.out.println(s);
				sum=sum+s;
			}
		}
		return sum;
	}

	private static int findSumOfDigits(int num) {
		int sum=0;
		while(num!=0)
		{
			int digit=num%10;
			sum=sum+digit;
			num=num/10;
		}
		return sum;
	}

	public static void findDuplicates(int[][] arr) {
		int[][] arr1=new int[arr.length][arr.length];
		int count=0;
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr.length-1;j++)
			{
				int num=arr[i][j];
				boolean flag=checkIfExists(num,arr1);
				if(!flag)
				{
					if(num==arr[i][j+1]||num==arr[i][j+1]+1)
					{
						arr1[count][count]=num;
						count++;
						break;
					}

				}
			}
		}
		if(count>0)
		{
			displayData(arr1);
		}
		else
		{
			System.out.println("Duplicate not found");
		}
	}

	private static boolean checkIfExists(int num, int[][] arr1) { 
	for(int i=0;i<arr1.length;i++)
	{
		for(int j=0;j<arr1.length;j++)
		{
			if(num==arr1[i][j])
			{
				return true;
			}			
		}
	}
	return false;
}

	public static void rotateArray(int num3, int[][] arr) {
		
		
	}

}
