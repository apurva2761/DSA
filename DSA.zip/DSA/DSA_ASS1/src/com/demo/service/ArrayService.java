package com.demo.service;
import java.util.Scanner;
public class ArrayService {

	public static void acceptData(int[] arr) {
		Scanner sc= new Scanner(System.in);
	 System.out.println("Enter elements:");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
	}

	public static void displayData(int[] arr) {
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
	}

	public static int maxElement(int[] arr) {
		int max=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
			}
		}
		return max;
	}
	
	public static int evenMaxElement(int[] arr) {
		// first even elements
		int i, max=0;
//		for(i=0;i<arr.length;i++)
//		{
//			if(arr[i]%2==0)
//			{
//				max=arr[i];
//				break;
//			}
//		}
//		for(int j=i+1;j<arr.length;j++)
//		{
//			if(arr[j]%2==0&& arr[j]>max)
//			{
//				max=arr[j];
//			}
//		}
//		
		for(i=0;i<arr.length;i++)
		{
			if(arr[i]%2==0)
			{
				if(arr[i]>max)
				{
					max=arr[i];
				}
			}
		}
		
		
		return max;
	}

	public static int findSumOfAllDigits(int[] arr) {
		int sum=0;
		for(int i=0;i<arr.length;i++)
		{
			int s=sumOfDigits(arr[i]);
			System.out.println(s);
			sum=sum+s;
		}
		return sum;
	}

	private static int sumOfDigits(int num) {
		int sum=0;
		while(num!=0)
		{
			int digit=num%10;
			sum=sum+digit;
			num=num/10;
		}
		return sum;
	}

	public static void findDuplicates(int[] arr) {
		int[] arr1=new int[arr.length/2];
		int count=0;
		for(int i=0;i<arr.length-1;i++)
		{
			int num=arr[i];
			boolean flag=checkIfExists(num,arr1);
			if(!flag)
			{
				for(int j=i+1;j<arr.length;j++)
				{
					if(num==arr[j])
					{
						arr1[count]=num;
						count++;
						break;
					}
				}
				
			}
		}
		if(count>0)
		{
			displayData(arr1);
		}
		else
		{
			System.out.println("Duplicate not found.");
		}
		
	}

	private static boolean checkIfExists(int num, int[] arr1) {
		for(int i=0;i<arr1.length;i++)
		{
			if(num==arr1[i])
			{
				return true;
			}
		}
		return false;
	}

	public static void rotateArray(int num3, int[] arr) {
		for(int i=0;i<num3;i++)
		{
			int temp=arr[0];
			for(int j=0;j<arr.length-1;j++)
			{
				arr[j]=arr[j+1];
			}
			arr[arr.length-1]=temp;
			
			System.out.println("Rotation "+i+1);
			displayData(arr);
			System.out.println(" -----------");
		}
		
	}

	
	
}
