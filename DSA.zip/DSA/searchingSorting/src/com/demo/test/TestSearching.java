package com.demo.test;

import java.util.Scanner;

import com.demo.service.SearchingService;

public class TestSearching {

	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter size of array");
    	int n=sc.nextInt();
    int [] arr= new int[n];
      SearchingService.acceptData(arr);
      SearchingService.displayData(arr);
      System.out.println("Enter element to be searched ");
      int num=sc.nextInt();
      System.out.println("1.sequential Search \n 2.Binary Search\n Choice:");
      int choice=sc.nextInt();
      if(choice==1)
      {
      SearchingService.sequentialSearch(arr,num);
      }else
      {
      SearchingService.binarySearch(arr,0,arr.length-1,num);
	}
	}
}
