package com.demo.test;

import java.util.Scanner;

import com.demo.service.SortingService;

public class TestSorting {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter array size");
		int n = sc.nextInt();
		int choice=0;
		int [] arr= new int [n];
		SortingService.acceptdata(arr);
		SortingService.displayData(arr);
		do {
		System.out.println("\n1.Bubble sort\n 2.selection sort\n 3.Quick sort\n 4.Merge sort\n 5.Insertion sort \n 6.Heap sort \n 7.Count sort \n8.exit choice:");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1: 
			int[] arr1=SortingService.bubbleSort(arr);
			SortingService.displayData(arr1);	
			break;

		case 2: 
			 arr1=SortingService.selectionSort(arr);
				SortingService.displayData(arr1);	

			break;

		case 3:
			 arr1=SortingService.quickSort(arr,0,arr.length-1);
				SortingService.displayData(arr1);	

			break;

		case 4:
			SortingService.mergesort(arr,0,arr.length-1);

			break;

		case 5:
			 arr1=SortingService.insertionSort(arr);
				SortingService.displayData(arr1);	

			break;

		case 6:
			SortingService.heapSort(arr);
			SortingService.displayData(arr);	

			break;
		case 7:
			arr1=SortingService.CountSort(arr);
			SortingService.displayData(arr1);	


			break;

		case 8:
			sc.close();
			System.out.println("Thank you !!!1");
			break;
			
			default:
				System.out.println("Invalid choice!!!!");
				break;
		}
		}while(choice!=8);
		
		

	}

}
