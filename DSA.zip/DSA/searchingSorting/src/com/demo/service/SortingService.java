package com.demo.service;

import java.util.Scanner;

public class SortingService {

	public static int[] bubbleSort(int[] arr) {
		int j;
		for(int i=0;i<arr.length-1;i++)
		{
			for( j=0;j<arr.length-i-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
			System.out.println(i+1+"iteration " );
			System.out.println(arr[j]);

		}
		return arr;
	}

	public static int[] selectionSort(int[] arr) {
		for(int i=0;i<arr.length-1;i++)
		{
			int min=i;
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[min]>arr[j])
				{
					min=j;
				}
			}
			int temp=arr[min];
			arr[min]=arr[i];
			arr[i]=temp;
			System.out.println(i+"iteration ---->"+arr[i] );

		}
		return arr;
	}

	public static int[] quickSort(int[] arr, int first, int last) {
		if(first<last) {
			int p=partition(arr,first,last);
			quickSort(arr,first,p-1);//left side
			quickSort(arr,p+1,last);//left side

	}
	return arr;
		}


	private static int partition(int[] arr, int first, int last) {
		int pivot=first;
		int i=first;
		int j=last;
		if(i<j)
		{
		while(i<j&&arr[i]<=arr[pivot])
		{
			i++;
		}
		while(j>pivot&&arr[j]>arr[pivot])
		{
			j--;
		}
		if(i<j)
		{
			int temp=arr[i];
			arr[i]=arr[j];
			arr[j]=temp;
		}
		}
		int temp=arr[j];
		arr[j]=arr[pivot];
		arr[pivot]=temp;
		return j;
	}

public static void mergesort(int[] arr, int start, int end) {
		if(start<end) {
			int mid=(start+end)/2;
			System.out.println("left tree start: "+start+" end : "+mid);
			mergesort(arr,start,mid);
			System.out.println("right tree start: "+(mid+1)+" end : "+end);
			mergesort(arr,mid+1,end);
			System.out.println("merge start: "+start+"mid: "+mid+" end : "+end);
			merge(arr,start,mid,end);
		}
		
	}
   
	private static void merge(int[] arr, int start, int mid, int end) {
		//length of leftarray
		int n1=mid-start+1;
		//length of right array
		int n2=end-mid;
		
		//temporary arrays
		int[] leftarray=new int[n1];
		int[] rightarray=new int[n2];
		//copy data to temp array
		for( int i=0;i<n1;i++) {
			leftarray[i]=arr[start+i];
		}
		for( int i=0;i<n2;i++) {
			rightarray[i]=arr[mid+1+i];
		}
		int i=0;
		int j=0;
		int k=start;
		while(i<n1 && j<n2) {
			if(leftarray[i]<=rightarray[j]) {
				arr[k]=leftarray[i];
				k++;
				i++;
			}else {
				arr[k]=rightarray[j];
				k++;
				j++;
			}
		}
		while(i<n1) {
			arr[k]=leftarray[i];
			k++;
			i++;
		}
		while(j<n2) {
			arr[k]=rightarray[j];
			k++;
			j++;
		}
		displayData(arr);
	}



	public static int[] insertionSort(int[] arr) {
		for(int i=1;i<arr.length;i++)
		{
			int key=arr[i];
			int j=i-1;
			while(j>=0&& key<arr[j])
			{
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=key;
		}
		return arr;
		
	}

	public static void heapSort(int[] arr) {
		int n=arr.length;
		for(int i=n/2-1;i>=0;i--)
		{
			heapify(arr,n,i);
		}
		for(int i=n-1;i>=0;i--)
		{
			int temp=arr[0];
			arr[0]=arr[i];
			arr[i]=temp;
			
			heapify(arr,i,0);
		}
	}

	private static void heapify(int[] arr, int n, int i) 
	{
		int largest=i;
		int left=2*i+1;
		int right=2*i+2;
		if(left<n && arr[left]>arr[largest])
		{
			largest=left;
		}
		if(right<n && arr[right]>arr[largest])
		{
			largest=right;
		}
		if(largest!=i)
		{
			int temp=arr[i];
			arr[i]=arr[largest];
			arr[largest]=temp;
			heapify(arr,i,largest);
		}
		
	}

	public static void acceptdata(int[] arr) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter array elements");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
	}

	public static void displayData(int[] arr) {
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+"\t");
		}		
	}

	public static int[] CountSort(int[] arr) {
		int max=findMax(arr);
		 int [] count= new int [max+1];
		 for(int i=0;i<count.length;i++)
		 {
			 count[i]=0;
		 }
		 displayData(count);
		 System.out.println();
		 // count of element
		 for(int i=0;i<arr.length;i++)
		 {
			 count[arr[i]]++;
		 }		
		 displayData(count);
		 System.out.println();


 // cumulative sum
		 for(int i=1;i<count.length;i++)
		 {
			 count[i]=count[i-1]+count[i];
		 }		
		 displayData(count);
		 System.out.println();


		 //array for output
		 int [] output=new int[arr.length];
		 for(int i=0;i<arr.length;i++)
		 {
			 int pos=count[arr[i]]-1;
			 output[pos]=arr[i];
			 count[arr[i]]--;
		 }
		 
		return output;
	}

	private static int findMax(int[] arr) {
		int max=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
			}
		}
		return max;
	}

}
