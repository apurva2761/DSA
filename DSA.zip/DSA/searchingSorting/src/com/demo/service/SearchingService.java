package com.demo.service;
import java.util.Scanner;
public class SearchingService {

	public static void acceptData(int[] arr) {
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter array elements");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
	
	}

	public static void displayData(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
	}
//sequential search
	public static void sequentialSearch(int[] arr, int num) {
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==num)
			{
				System.out.println("Element" +num+" found at position "+i);
			}
			
		}
		System.out.println("Element not found");

	}

	public static void binarySearch(int[] arr, int low, int high, int num2) {
		if (low <= high) {
			
			int mid=(low+high)/2;
			if(arr[mid]==num2)
			{
				System.out.println("element"+num2+" found at "+mid);
			}
			else if(arr[mid]>num2)
			{
				binarySearch(arr, low, mid-1, num2);//left side
			}
			else
			{
				binarySearch(arr, mid+1, high, num2);//right side
			}
					

		}
		
		  else { System.out.println("Element Not Found"); }
		 
		
	}

}
