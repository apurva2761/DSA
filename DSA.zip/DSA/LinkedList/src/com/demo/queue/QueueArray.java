package com.demo.queue;

public class QueueArray {
	int [] arr;
	int front;
	int rear;

	public QueueArray(int size) {
		arr= new int[size];
		front=-1;
		rear=-1;
	}
	public boolean isFull()
	{
		if(rear==arr.length-1)
		{
			System.out.println("Queue is full");
			return true;
		}
		return false ;
		
	}
	public boolean isEmpty()
	{
		if( front==-1)
		{
			System.out.println("Queue is Empty");
			return true;
		}
		return false ;
		
	}

	public void equeue(int val) {
		if(!isFull())
		{ rear++;
			arr[rear]=val;
			if(front==-1)
			{
				front++;
			}
			
		}else {
			System.out.println("Queue is full");
		}
		
	}

	public void displayData() {
		for(int i: arr)
		{
			System.out.println(i+",");
		}
		System.out.println("\n--------------------------\n");
	}

	public int dequeue() {
		int n;
		if(!isEmpty())
		{
			n=arr[front];
			front++;
			if(front==arr.length)
			{
				front=-1;
			}
			return n;
		}
		
		return -1;
		
	}
	

}
