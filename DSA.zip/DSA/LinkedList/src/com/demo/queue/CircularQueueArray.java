package com.demo.queue;

public class CircularQueueArray {
	int[] arr;
	int front;
	int rear;

	public CircularQueueArray(int size) {
		super();
		arr=new int[size];
		rear=-1;
		front=-1;
		
	}

	public boolean isEmpty() {
		if(front==-1)
		{
			System.out.println("Queue is empty");
			return true;
		}
		return false;
	}
	public boolean isFull()
	{
		if(rear==arr.length-1&& front==0&&front==rear+1)
		{
			System.out.println("Queue is full");
			return true;
		}
		return false;
	}

	public void enqueue(int val) {
		if(!isFull())
		{
			if(isEmpty())
			{
			front++;
			}
			rear=(rear+1)%arr.length;
			arr[rear]=val;		
		
		}
	}
	public int dequeue()
	{
		int n;
		if(!isEmpty())
		{
			if(front==rear)
			{
				n=arr[front];
				front=-1;
				rear=-1;
				return n;
			}else
			{
			 n=arr[front];
			front=(front+1)%arr.length;
			}
			return n;
		}
		return -1;
	}

	public void displayData() {
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
		System.out.println();
	}

}
