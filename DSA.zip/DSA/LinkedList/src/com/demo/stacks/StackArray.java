package com.demo.stacks;

public class StackArray {
	int []arr;
	int top;

	public StackArray(int size) {
		super();
		arr=new int [size];
		top=-1;
	}
	
public boolean isFull() {
	if(top==arr.length-1)
	{
		System.out.println("stack is full");
		return true;
	}
	return false;
}
public boolean isEmpty() {
	if(top==-1)
	{
		System.out.println("Stack is empty");
		return true;
	}
	return false;
}

public void push(int val) {
	if(!isFull())
	{	
		top++;
		arr[top]=val;
	}
}
public int pop() {
	if(!isEmpty())
	{
		int n=arr[top];
		top--;
		return n;
	}
	return -1;
}

public void displayData() {
for(int i:arr)
{
	System.out.print(i+" ");
}
System.out.println();
}

}
