package com.demo.test;

import com.demo.queue.QueueLinkedList;

public class TestQueueLinkedList {

	public static void main(String[] args) {
		QueueLinkedList qllist=new QueueLinkedList();
		qllist.enqueue(12);
		qllist.enqueue(13);
		qllist.enqueue(15);
		qllist.enqueue(14);
		qllist.enqueue(16);
		
		qllist.displayData();

		while(!qllist.isEmpty())
		{
			System.out.println(qllist.dequeue());
		}
}

}
