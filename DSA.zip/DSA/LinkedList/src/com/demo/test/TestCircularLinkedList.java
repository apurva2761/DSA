package com.demo.test;
import java.util.Scanner;

import com.demo.linkedlist.circularLinkedList;

public class TestCircularLinkedList {

	public static void main(String[] args) {
		circularLinkedList lst=new circularLinkedList();
		Scanner sc=new Scanner(System.in);
		lst.addNewNode(1,5);
		lst.addNewNode(1,6);
		lst.addNewNode(2,7);
		lst.addNewNode(4,8);
		lst.displayData();
		lst.deleteByPos(4);
		lst.displayData();

	}

}
