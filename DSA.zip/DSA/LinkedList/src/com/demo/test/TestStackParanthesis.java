package com.demo.test;

import com.demo.stacks.StackLinkedList;
import java.util.Scanner;

public class TestStackParanthesis {

	public static void main(String[] args) {
		StackLinkedList<Character> s= new StackLinkedList<>();
		Scanner sc= new Scanner(System.in);
		String s1=sc.next();
		boolean flag=true;
		for(int i=0;i<s1.length();i++)
		{
			Character c=s1.charAt(i);
			if(c=='('||c=='{'||c=='[')
			{
				s.push(c);
			}
			else
			{
				if(!s.isEmpty())
				{ 
					Character ch=s.pop();
					switch(c)
					{
					case ')':
						if(ch!='(')
						{
							flag=false;
							System.out.println("NO Balanced paranthesis");
						}
						break;
					case '}':
						if(ch!='{')
						{
							flag=false;
							System.out.println("NO Balanced paranthesis");
						}
						break;
					case ']':
						if(ch!='[')
						{
							flag=false;
							System.out.println("NO Balanced paranthesis");
						}
						break;
					}
				}
				else {
					flag=false;
					System.out.println("NO Balanced paranthesis");
				}
			}
			if(!flag)
			{
				break;
			}
		
		}
		
		if(flag && s.isEmpty())
		{
			System.out.println("Balanced paranthesis");
		}
	}

}
