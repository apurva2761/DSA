package com.demo.test;
import com.demo.stacks.*;
import java.util.Scanner;

public class TestStackLinkedList{

	public static void main(String[] args) {
		StackLinkedList stack=new StackLinkedList();
		//Scanner sc=new Scanner(System.in);
		stack.push(20);
		stack.push(21);
		stack.push(22);
		stack.push(23);
		stack.push(24);
		stack.displayData();
		while(!stack.isEmpty())
		{
		System.out.println(stack.pop());
		}
		System.out.println("stack is empty");


		
		
	}

}
