package com.demo.test;
import java.util.Scanner;
import com.demo.linkedlist.LinkedList;
import com.demo.service.*;
public class TestLinkedList 
{

	public static void main(String[] args) 
		{
		LinkedList mylist=new LinkedList();
		mylist.addNode(1);
		mylist.addNode(2);
		mylist.addNode(3);
		mylist.displayData();
		mylist.addByPosition(1,4);
		mylist.displayData();
		mylist.addByPosition(2,4);
		mylist.displayData();
		mylist.addByPosition(5,6);
		mylist.displayData();
		mylist.addByPosition(7,8);
		mylist.displayData();
		mylist.addByValue(10,4);
		mylist.displayData();
		mylist.deleteByPosition(7);
		mylist.displayData();
		mylist.deleteByValue(4);
		mylist.displayData();
		mylist.displayEvenData();


			}
}


