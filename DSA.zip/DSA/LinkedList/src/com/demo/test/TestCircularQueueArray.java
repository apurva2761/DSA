package com.demo.test;

import com.demo.queue.CircularQueueArray;

public class TestCircularQueueArray {

	public static void main(String[] args) {
		CircularQueueArray cqarr=new CircularQueueArray(5);
		cqarr.enqueue(12);
		cqarr.enqueue(24);
		cqarr.enqueue(13);
		cqarr.enqueue(14);
		cqarr.enqueue(11);

		cqarr.displayData();
		
		while(!cqarr.isEmpty())
		{
			System.out.println(cqarr.dequeue());
		}
	}

}
