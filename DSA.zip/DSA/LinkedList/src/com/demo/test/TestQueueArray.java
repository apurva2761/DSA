package com.demo.test;
import com.demo.queue.*;
public class TestQueueArray {

	public static void main(String[] args) {
	
	QueueArray qarr=new QueueArray(5);
	qarr.equeue(12);
	qarr.equeue(10);
	qarr.equeue(13);
	qarr.equeue(15);
	qarr.equeue(18);
	qarr.displayData();
	
	while(!qarr.isEmpty())
	{
			System.out.println(qarr.dequeue()); 

	}
	

	}

}
