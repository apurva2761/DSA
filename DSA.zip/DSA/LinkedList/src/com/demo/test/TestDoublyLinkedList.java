package com.demo.test;
import com.demo.linkedlist.*;
public class TestDoublyLinkedList {

	public static void main(String[] args) {
		DoublyLinkedList lst= new DoublyLinkedList();
		lst.addNewNodeByPossition(12,1);
		lst.addNewNodeByPossition(10,2);
		lst.addNewNodeByPossition(14,3);
		lst.displayData();
		lst.addNewNodeByPossition(18,2);
		lst.displayData();
		lst.addNewNodeByValue(2,18);
		lst.displayData();
		lst.deleteBYPosition(3);
		lst.displayData();


	}

}
