package com.demo.test;
import com.demo.stacks.*;

public class TestStackArray {
	public static void main(String[] args) {
		StackArray sarr=new StackArray(5);
		sarr.push(10);
		sarr.push(30);
		sarr.push(50);
		sarr.push(20);
		sarr.push(40);
		sarr.displayData();
		
		while(!sarr.isEmpty())
		{
			System.out.println(sarr.pop());
		}
	}

}
