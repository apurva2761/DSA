package com.demo.service;

import java.util.Scanner;

import com.demo.linkedlist.EmpLinkedList;
import com.demo.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {
	private EmpLinkedList lst;
	 

	public EmployeeServiceImpl() {
		super();
		lst=new EmpLinkedList();
	}

	@Override
	public void addnewEmp() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id");
		int id=sc.nextInt();
		System.out.println("Enter name");
		String name=sc.next();
		System.out.println("Enter salary");
		double salary=sc.nextDouble();
		System.out.println("Enter pos");
		int pos=sc.nextInt();
		lst.addByPosition(new Employee(id,name,salary),pos);
	
	}

	@Override
	public void displayall() {
		lst.displayAll();
	}

	@Override
	public void displayByName(String nm) {
		lst.displayByName(nm);
	}
	@Override
	public void displayById(int id) {
        lst.displayById(id);		
		
	}

	@Override
	public void deleteById(int id) {
		lst.deleteById(id);
	}



}
