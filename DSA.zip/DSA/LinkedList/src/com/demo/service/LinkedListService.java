package com.demo.service;
import java.util.Scanner;


public class LinkedListService {



}
