package com.demo.linkedlist;

import com.demo.model.Employee;

public class EmpLinkedList {
	public Node head;
	class Node{
		Employee data;
		Node next;
	
	Node(Employee ob){
		data=ob;
		next=null;
	}
	}
	public void addByPosition(Employee ob, int pos) {
		Node newNode=new Node(ob);
		if(head==null)
		{
			head=newNode;
			System.out.println("Added successful");
		}
		else
		{
			if(pos==1)
			{
				newNode.next=head;
				head=newNode;
				System.out.println("Added successful");

			}
			else
			{
				Node temp=head;
				for(int i=1;temp!=null&&i<pos-1;i++)
				{
					temp=temp.next;
				}
				if(temp!=null)
				{
					newNode.next=temp.next;
					temp.next=newNode;
					System.out.println("Added successful");

				}
			}
		}
	}
	public void displayAll() {
		if(head==null)
		{
			System.out.println("List is empty");
		}
		else
		{
			for(Node temp=head;temp!=null;temp=temp.next)
			{
				System.out.println(temp.data+" ");
			}
			System.out.println("\n----------------------------------------------------");
		}
	}
	public void displayByName(String nm) {
		if(head==null)
		{
			System.out.println("List is empty");
		}
		else
		{
			for(Node temp=head;temp!=null;temp=temp.next)
			{
				if(temp.data.getEname().equals(nm))
				{
					System.out.println(temp.data+" ");

				}
	         }
		}
	}
	public void displayById(int id) {
		if(head==null)
		{
			System.out.println("List is empty");
		}
		else
		{
			for(Node temp=head;temp!=null;temp=temp.next)
			{
				if(temp.data.getEid()==id)
				{
					System.out.println(temp.data+" ");

				}
	         }
		}

	}
	public void deleteById(int id) {
		if(head==null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node temp=head;
			Node prev=null;
			while(temp!=null && temp.data.getEid()!= id)
			{
				prev=temp;
				temp=temp.next;
			}
			if(temp!=null)
			{
				prev.next=temp.next;
				temp.next=null;
				temp=null;
			}
			else
			{
				System.out.println("Id not found");
			}
	}
}
}
