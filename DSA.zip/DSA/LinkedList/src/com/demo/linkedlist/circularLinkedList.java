package com.demo.linkedlist;

public class circularLinkedList {
	public Node head;
	public Node last;
	class Node{
		int data;
		Node next;
		public Node() {
			data=0;
			next=null;
		}
		public Node(int val)
		{
			data=val;
			next=null;
		}
	}
	
	public void addNewNode(int pos,int val) {
		Node newNode=new Node(val);
		if(head==null)
		{
			head=newNode;
			last=newNode;
			newNode.next=head;
		}else {
			if(pos==1)
			{
				newNode.next=head.next;
				head=newNode;
				last.next=head;
			}
			else
			{
				Node temp=head;
				for(int i=1;i<pos-1&&temp!=last;i++)
				{
					temp=temp.next;
				}
				newNode.next=temp.next;
				temp.next=newNode;
				if(temp==last)
				{
					last=newNode;
				}
			}
		}
	}

	public void displayData() {
		Node temp;
		if(head==null)
		{
			System.out.println("List is empty");
		}
		for(temp=head;temp!=last;temp=temp.next)
		{
			System.out.println(temp.data+" ");
		}
		System.out.println(temp.data+" ");
		System.out.println("\n---------------------------\n");
	}

	public void deleteByPos(int pos) {
		if(head==null)
		{
			System.out.println("List is empty.");
		}
		else {
			Node temp=head;
			Node prev=null;
			if(pos==1)
			{
				if(head==last)
				{
					head=null;
					last=null;
				}
				else {
					head=head.next;
					last.next=head;
					temp.next=null;
					temp=null;
					
				}
			}
			else {
				for(int i=0;i<pos-1&&temp!=last;i++)
				{
					prev=temp;
					temp=temp.next;
				}
				prev.next=temp.next;
				if(temp==last)
				{
					last=prev;
				}
				temp.next=null;
				temp=null;
				
			}
		}
	}

}
