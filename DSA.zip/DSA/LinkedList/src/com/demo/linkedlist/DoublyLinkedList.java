package com.demo.linkedlist;

public class DoublyLinkedList {
	public Node head;
	class Node{
		int data;
		Node next;
		Node prev;
		Node()
		{
			data=0;
			next=null;
			prev=null;
		}
		Node(int val)
		{
			data=val;
			next=null;
			prev = null;
		}
	}
	
	public void addNewNodeByPossition(int val, int pos) {
		Node newNode= new Node(val);
		if(head==null)
		{
			head=newNode;
		}
		else
		{
			Node temp=head;
			
			if(pos==1)
			{
				newNode.next=head;
				head=newNode;
			}
			else
			{
				for(int i=1;temp!=null && i< pos-1;i++)
				{
					temp=temp.next;
				}
				if(temp!= null)
				{
					newNode.next=temp.next;
					temp.next=newNode;
				}
			}
		}
		
	}

	public void displayData() {
	if(head==null)
	{
		System.out.println("list is empty");
	}
	else
	{
		for(Node temp=head;temp!= null ;temp=temp.next)
		{
			System.out.print(temp.data+" ");
		}
		System.out.println("\n-----------------------------");
	}
	}

	public void addNewNodeByValue(int val, int val1) {
		Node newNode= new Node(val);
		if(head.data==val1)
		{
			head.next=newNode;
		}
		else
		{
			Node temp=head;
			while(temp!=null && temp.data!= val1)
			{
				temp=temp.next;
			}
			if(temp!= null)
			{
				newNode.next=temp.next;
				temp.next=newNode;
			}
		}
	}

	public void deleteBYPosition(int pos) {
	if(head==null)
	{
		System.out.println("list is empty");
	}else
	{
		Node temp=head;
		for(int i=0; temp != null && i<pos-1;i++)
		{
			temp=temp.next;
		}
		if(temp!= null)
		{
			temp.prev.next=temp.next;
			if(temp.next!=null) {
			temp.next.prev=temp.prev;
			}
			temp.next=null;
			temp.prev=null;
			temp=null;
		}
	}
		
	}
	

}
