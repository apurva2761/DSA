package com.demo.queue;

public class QueueLinkedList {
	public Node rear=null;
	public Node front=null;

	class Node{
		int data;
		Node next;
		Node(int val){
			data=val;
			next=null;
					}
	}
 
	public boolean isEmpty()
	{
		if(front==null)
		{
			System.out.println("Queue is empty");
			return true;
		}
		return false;
	}
	public void enqueue(int val) {
		Node newNode=new Node(val);
		if(isEmpty())
		{
			rear=newNode;
			front=newNode;

		}
		else
		{
			rear.next=newNode;
			rear=newNode;
		}
	}
	public int dequeue() {
		int n=front.data;
		if(!isEmpty())
		{
			if(rear==front)
			{
				front=null;
				rear=null;
			}
			else {
				Node temp=front;
				front=front.next;
				temp.next=null;
				temp=null;
			}
			return n;

		}
		System.out.println("Queue is empty");
		return -1;
	}
	public void displayData() {
		for(Node temp=front;temp!=null;temp=temp.next)
		{
			System.out.println(temp.data);
		}
		System.out.println();
	}

}
