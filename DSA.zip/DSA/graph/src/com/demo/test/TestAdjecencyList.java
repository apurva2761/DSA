package com.demo.test;

import com.demo.graph.AdjecencyList;

public class TestAdjecencyList {

	public static void main(String[] args) {
		AdjecencyList alist= new AdjecencyList(5);
		alist.addGraph();
		alist.displayGraph();
		
	}

}
