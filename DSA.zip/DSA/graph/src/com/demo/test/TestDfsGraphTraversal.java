package com.demo.test;

import com.demo.graph.DfsGraphTraversal;

public class TestDfsGraphTraversal {

	public static void main(String[] args) {
		DfsGraphTraversal dfs= new DfsGraphTraversal(7);
		dfs.addGraph();
		dfs.displayGraph();
		//dfs.dfsTraverse(0);
		dfs.bfsTraverse(0);
	}

}
