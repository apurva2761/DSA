package com.demo.test;

import com.demo.graph.AdjecencyMatrix;

public class TestAdjecencyMatrix {

	public static void main(String[] args) {
		AdjecencyMatrix matrix= new AdjecencyMatrix(5);
		matrix.addGraph();
		matrix.displayGraph();
	}

}
