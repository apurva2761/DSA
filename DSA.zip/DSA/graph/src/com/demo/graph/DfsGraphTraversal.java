package com.demo.graph;

import java.util.Scanner;

import com.demo.queue.QueueLinkedList;
import com.demo.stacks.StackLinkedList;

public class DfsGraphTraversal {
	Node[] head;
	public DfsGraphTraversal(int num)
	{
		head= new Node[num];
	}
	class Node
	{
		int data;
		Node next;
		public Node(int val)
		{
			data= val;
			next= null;
		}
	}

	public void addGraph() {
	Scanner sc= new Scanner(System.in);
	for(int i=0;i<head.length;i++)
	{
		for(int j =0;j<head.length;j++)
		{
			System.out.println("edge"+i+"-------->"+j+":");
			int num=sc.nextInt();
			if(num==1)
			{
				Node newNode=new Node(j);
				if(head[i]==null)
				{
					head[i]=newNode;
				}
				else
				{
					newNode.next=head[i];
					head[i]=newNode;
				}
			}
		}
	}
	}

	public void displayGraph() {
		for(int i=0;i<head.length;i++)
		{ 
			System.out.println("Node"+i+":");
			for(Node temp =head[i];temp!=null;temp=temp.next)
			{
				System.out.print(temp.data+",");
			}
			System.out.println("null\n");
		}
	}

	public void dfsTraverse(int n) {
		StackLinkedList<Integer> dlist= new StackLinkedList<>();
		dlist.push(n);
		int []mydfs= new int[head.length];
		int cnt=0;
		boolean[] visited= new boolean[head.length];
		for(int i=0;i<head.length;i++)
		{
			visited[i]=false;
		}
		while(!dlist.isEmpty())
		{
			int d=dlist.pop();
			if(!visited[d])
			{
				visited[d]=true;
				mydfs[cnt]=d;
				cnt++;
				for(Node temp=head[d];temp!=null;temp=temp.next)
				{
					if(!visited[temp.data])
					{
						dlist.push(temp.data);
					}
				}
			}
			}
		for(int n1:mydfs)
		{
			System.out.println(n1+",");
		}
	}

	public void bfsTraverse(int n) {
	 QueueLinkedList qlist= new QueueLinkedList();	
	 qlist.enqueue(n);
	 int [] mybfs= new int[head.length];
	 int cnt=0;
	 boolean visited[]=new boolean[head.length];
	 for(int i=0;i<head.length;i++)
	 {
		 visited[i]=false;
	 }
	 while(!qlist.isEmpty())
	 {
		 int d=qlist.dequeue();
		 if(!visited[d])
		 {
			 visited[d]=true;
			 mybfs[cnt]=d;
			 cnt++;
			 for(Node temp=head[d];temp!=null;temp=temp.next)
			 {
				 if(!visited[temp.data])
				 {
					 qlist.enqueue(temp.data);
				 }
			 }
		 }
	 }
	 for(int n1:mybfs)
	 {
		 System.out.println(n1+" ,");
	 }
	 
	}
}
