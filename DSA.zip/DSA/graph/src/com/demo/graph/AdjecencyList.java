package com.demo.graph;

import java.util.Scanner;

public class AdjecencyList {
	Node[] head;
	public AdjecencyList(int num)
	{
		head= new Node[num];
	}
	class Node
	{
		int data;
		Node next;
		public Node(int val)
		{
			data= val;
			next= null;
		}
	}

	public void addGraph() {
	Scanner sc= new Scanner(System.in);
	for(int i=0;i<head.length;i++)
	{
		for(int j =0;j<head.length;j++)
		{
			System.out.println("edge"+i+"-------->"+j+":");
			int num=sc.nextInt();
			if(num==1)
			{
				Node newNode=new Node(j);
				if(head[i]==null)
				{
					head[i]=newNode;
				}
				else
				{
					newNode.next=head[i];
					head[i]=newNode;
				}
			}
		}
	}
	}

	public void displayGraph() {
		for(int i=0;i<head.length;i++)
		{ 
			System.out.println("Node"+i+":");
			for(Node temp =head[i];temp!=null;temp=temp.next)
			{
				System.out.print(temp.data+",");
			}
			System.out.println("null\n");
		}
	}
}
