package com.demo.graph;

import java.util.Scanner;

public class AdjecencyMatrix {
	public int[][] graph;
	public AdjecencyMatrix(int num) {
		graph= new int [num][num];
		
	}
	public void addGraph() {
		Scanner sc= new Scanner(System.in);
		for(int i= 0;i<graph.length;i++)
		{
			for(int j= 0;j<graph.length;j++)
			{	
				System.out.println("edge"+i+"----->"+j+":");
				graph[i][j]=sc.nextInt();
			}
		}
	}
	public void displayGraph() {
		for(int i= 0;i<graph.length;i++)
		{
			for(int j= 0;j<graph.length;j++)
			{	
				//System.out.println("edge"+i+"----->"+j+":");
     			System.out.print( graph[i][j]+"  ");
			}
			System.out.println();
		}
	
	}	
}
